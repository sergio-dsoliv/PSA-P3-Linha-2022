﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPP6 = New System.Windows.Forms.TextBox()
        Me.txtPP5 = New System.Windows.Forms.TextBox()
        Me.txtPP4 = New System.Windows.Forms.TextBox()
        Me.txtPP3 = New System.Windows.Forms.TextBox()
        Me.txtPP2 = New System.Windows.Forms.TextBox()
        Me.txtPP1 = New System.Windows.Forms.TextBox()
        Me.Btnget = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtdestino = New System.Windows.Forms.ComboBox()
        Me.Txtpalete = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Btnmove = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.BtnX3 = New System.Windows.Forms.CheckBox()
        Me.BtnX2 = New System.Windows.Forms.CheckBox()
        Me.BtnX5 = New System.Windows.Forms.CheckBox()
        Me.BtnX4 = New System.Windows.Forms.CheckBox()
        Me.BtnX0 = New System.Windows.Forms.CheckBox()
        Me.BtnX1 = New System.Windows.Forms.CheckBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Btnoperacao = New System.Windows.Forms.CheckBox()
        Me.Btndistribuicao = New System.Windows.Forms.CheckBox()
        Me.Btncontagem = New System.Windows.Forms.CheckBox()
        Me.Btninicializa = New System.Windows.Forms.CheckBox()
        Me.Btnencerrar = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.BaseDeDadosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConnectToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.BtnLigarmotor = New System.Windows.Forms.Button()
        Me.ShowBDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtPP6)
        Me.GroupBox1.Controls.Add(Me.txtPP5)
        Me.GroupBox1.Controls.Add(Me.txtPP4)
        Me.GroupBox1.Controls.Add(Me.txtPP3)
        Me.GroupBox1.Controls.Add(Me.txtPP2)
        Me.GroupBox1.Controls.Add(Me.txtPP1)
        Me.GroupBox1.Controls.Add(Me.Btnget)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 31)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(776, 90)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Posições Atuais"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(571, 27)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 16)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Palete 6"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(460, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 16)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Palete 5"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(354, 27)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 16)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Palete 4"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(250, 27)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 16)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Palete 3"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(140, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 16)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Palete 2"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 16)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Palete 1"
        '
        'txtPP6
        '
        Me.txtPP6.Location = New System.Drawing.Point(574, 46)
        Me.txtPP6.Name = "txtPP6"
        Me.txtPP6.Size = New System.Drawing.Size(26, 22)
        Me.txtPP6.TabIndex = 6
        '
        'txtPP5
        '
        Me.txtPP5.Location = New System.Drawing.Point(463, 46)
        Me.txtPP5.Name = "txtPP5"
        Me.txtPP5.Size = New System.Drawing.Size(26, 22)
        Me.txtPP5.TabIndex = 5
        '
        'txtPP4
        '
        Me.txtPP4.Location = New System.Drawing.Point(357, 46)
        Me.txtPP4.Name = "txtPP4"
        Me.txtPP4.Size = New System.Drawing.Size(26, 22)
        Me.txtPP4.TabIndex = 4
        '
        'txtPP3
        '
        Me.txtPP3.Location = New System.Drawing.Point(253, 46)
        Me.txtPP3.Name = "txtPP3"
        Me.txtPP3.Size = New System.Drawing.Size(26, 22)
        Me.txtPP3.TabIndex = 3
        '
        'txtPP2
        '
        Me.txtPP2.Location = New System.Drawing.Point(143, 46)
        Me.txtPP2.Name = "txtPP2"
        Me.txtPP2.Size = New System.Drawing.Size(26, 22)
        Me.txtPP2.TabIndex = 2
        '
        'txtPP1
        '
        Me.txtPP1.Location = New System.Drawing.Point(34, 46)
        Me.txtPP1.Name = "txtPP1"
        Me.txtPP1.Size = New System.Drawing.Size(26, 22)
        Me.txtPP1.TabIndex = 1
        '
        'Btnget
        '
        Me.Btnget.Location = New System.Drawing.Point(682, 21)
        Me.Btnget.Name = "Btnget"
        Me.Btnget.Size = New System.Drawing.Size(73, 47)
        Me.Btnget.TabIndex = 0
        Me.Btnget.Text = "Get Position"
        Me.Btnget.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtdestino)
        Me.GroupBox2.Controls.Add(Me.Txtpalete)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Btnmove)
        Me.GroupBox2.Location = New System.Drawing.Point(443, 136)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(220, 124)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Ordens Locais"
        '
        'txtdestino
        '
        Me.txtdestino.FormattingEnabled = True
        Me.txtdestino.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6"})
        Me.txtdestino.Location = New System.Drawing.Point(143, 53)
        Me.txtdestino.Name = "txtdestino"
        Me.txtdestino.Size = New System.Drawing.Size(72, 24)
        Me.txtdestino.TabIndex = 14
        '
        'Txtpalete
        '
        Me.Txtpalete.FormattingEnabled = True
        Me.Txtpalete.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6"})
        Me.Txtpalete.Location = New System.Drawing.Point(13, 53)
        Me.Txtpalete.Name = "Txtpalete"
        Me.Txtpalete.Size = New System.Drawing.Size(72, 24)
        Me.Txtpalete.TabIndex = 13
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(147, 34)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 16)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Destino"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(29, 34)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 16)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Palete "
        '
        'Btnmove
        '
        Me.Btnmove.Location = New System.Drawing.Point(76, 94)
        Me.Btnmove.Name = "Btnmove"
        Me.Btnmove.Size = New System.Drawing.Size(75, 23)
        Me.Btnmove.TabIndex = 0
        Me.Btnmove.Text = "Move P D"
        Me.Btnmove.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.BtnX3)
        Me.GroupBox3.Controls.Add(Me.BtnX2)
        Me.GroupBox3.Controls.Add(Me.BtnX5)
        Me.GroupBox3.Controls.Add(Me.BtnX4)
        Me.GroupBox3.Controls.Add(Me.BtnX0)
        Me.GroupBox3.Controls.Add(Me.BtnX1)
        Me.GroupBox3.Controls.Add(Me.PictureBox1)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 136)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(425, 245)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Monitorização"
        '
        'BtnX3
        '
        Me.BtnX3.AutoSize = True
        Me.BtnX3.Location = New System.Drawing.Point(130, 43)
        Me.BtnX3.Name = "BtnX3"
        Me.BtnX3.Size = New System.Drawing.Size(18, 17)
        Me.BtnX3.TabIndex = 6
        Me.BtnX3.UseVisualStyleBackColor = True
        '
        'BtnX2
        '
        Me.BtnX2.AutoSize = True
        Me.BtnX2.Location = New System.Drawing.Point(108, 86)
        Me.BtnX2.Name = "BtnX2"
        Me.BtnX2.Size = New System.Drawing.Size(18, 17)
        Me.BtnX2.TabIndex = 5
        Me.BtnX2.UseVisualStyleBackColor = True
        '
        'BtnX5
        '
        Me.BtnX5.AutoSize = True
        Me.BtnX5.Location = New System.Drawing.Point(295, 94)
        Me.BtnX5.Name = "BtnX5"
        Me.BtnX5.Size = New System.Drawing.Size(18, 17)
        Me.BtnX5.TabIndex = 4
        Me.BtnX5.UseVisualStyleBackColor = True
        '
        'BtnX4
        '
        Me.BtnX4.AutoSize = True
        Me.BtnX4.Location = New System.Drawing.Point(209, 57)
        Me.BtnX4.Name = "BtnX4"
        Me.BtnX4.Size = New System.Drawing.Size(18, 17)
        Me.BtnX4.TabIndex = 3
        Me.BtnX4.UseVisualStyleBackColor = True
        '
        'BtnX0
        '
        Me.BtnX0.AutoSize = True
        Me.BtnX0.Location = New System.Drawing.Point(295, 132)
        Me.BtnX0.Name = "BtnX0"
        Me.BtnX0.Size = New System.Drawing.Size(18, 17)
        Me.BtnX0.TabIndex = 2
        Me.BtnX0.UseVisualStyleBackColor = True
        '
        'BtnX1
        '
        Me.BtnX1.AutoSize = True
        Me.BtnX1.Location = New System.Drawing.Point(164, 112)
        Me.BtnX1.Name = "BtnX1"
        Me.BtnX1.Size = New System.Drawing.Size(18, 17)
        Me.BtnX1.TabIndex = 1
        Me.BtnX1.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(6, 21)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(419, 224)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Btnoperacao)
        Me.GroupBox4.Controls.Add(Me.Btndistribuicao)
        Me.GroupBox4.Controls.Add(Me.Btncontagem)
        Me.GroupBox4.Controls.Add(Me.Btninicializa)
        Me.GroupBox4.Location = New System.Drawing.Point(443, 259)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(220, 122)
        Me.GroupBox4.TabIndex = 3
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Estágio"
        '
        'Btnoperacao
        '
        Me.Btnoperacao.AutoSize = True
        Me.Btnoperacao.Location = New System.Drawing.Point(13, 96)
        Me.Btnoperacao.Name = "Btnoperacao"
        Me.Btnoperacao.Size = New System.Drawing.Size(90, 20)
        Me.Btnoperacao.TabIndex = 3
        Me.Btnoperacao.Text = "Operação"
        Me.Btnoperacao.UseVisualStyleBackColor = True
        '
        'Btndistribuicao
        '
        Me.Btndistribuicao.AutoSize = True
        Me.Btndistribuicao.Location = New System.Drawing.Point(13, 73)
        Me.Btndistribuicao.Name = "Btndistribuicao"
        Me.Btndistribuicao.Size = New System.Drawing.Size(100, 20)
        Me.Btndistribuicao.TabIndex = 2
        Me.Btndistribuicao.Text = "Distribuição"
        Me.Btndistribuicao.UseVisualStyleBackColor = True
        '
        'Btncontagem
        '
        Me.Btncontagem.AutoSize = True
        Me.Btncontagem.Location = New System.Drawing.Point(13, 47)
        Me.Btncontagem.Name = "Btncontagem"
        Me.Btncontagem.Size = New System.Drawing.Size(91, 20)
        Me.Btncontagem.TabIndex = 1
        Me.Btncontagem.Text = "Contagem"
        Me.Btncontagem.UseVisualStyleBackColor = True
        '
        'Btninicializa
        '
        Me.Btninicializa.AutoSize = True
        Me.Btninicializa.Location = New System.Drawing.Point(13, 21)
        Me.Btninicializa.Name = "Btninicializa"
        Me.Btninicializa.Size = New System.Drawing.Size(103, 20)
        Me.Btninicializa.TabIndex = 0
        Me.Btninicializa.Text = "Inicialização"
        Me.Btninicializa.UseVisualStyleBackColor = True
        '
        'Btnencerrar
        '
        Me.Btnencerrar.Location = New System.Drawing.Point(694, 395)
        Me.Btnencerrar.Name = "Btnencerrar"
        Me.Btnencerrar.Size = New System.Drawing.Size(85, 26)
        Me.Btnencerrar.TabIndex = 4
        Me.Btnencerrar.Text = "Encerrar"
        Me.Btnencerrar.UseVisualStyleBackColor = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 424)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(800, 26)
        Me.StatusStrip1.TabIndex = 5
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(77, 20)
        Me.ToolStripStatusLabel1.Text = "Desligado"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BaseDeDadosToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 28)
        Me.MenuStrip1.TabIndex = 6
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'BaseDeDadosToolStripMenuItem
        '
        Me.BaseDeDadosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConnectToolStripMenuItem, Me.ShowBDToolStripMenuItem})
        Me.BaseDeDadosToolStripMenuItem.Name = "BaseDeDadosToolStripMenuItem"
        Me.BaseDeDadosToolStripMenuItem.Size = New System.Drawing.Size(120, 24)
        Me.BaseDeDadosToolStripMenuItem.Text = "Base de dados"
        '
        'ConnectToolStripMenuItem
        '
        Me.ConnectToolStripMenuItem.Name = "ConnectToolStripMenuItem"
        Me.ConnectToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.ConnectToolStripMenuItem.Text = "connect"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(12, 399)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(26, 22)
        Me.TextBox1.TabIndex = 7
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 200
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(679, 179)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 22)
        Me.TextBox2.TabIndex = 8
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(679, 226)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 22)
        Me.TextBox3.TabIndex = 9
        '
        'BtnLigarmotor
        '
        Me.BtnLigarmotor.Location = New System.Drawing.Point(698, 280)
        Me.BtnLigarmotor.Name = "BtnLigarmotor"
        Me.BtnLigarmotor.Size = New System.Drawing.Size(69, 46)
        Me.BtnLigarmotor.TabIndex = 10
        Me.BtnLigarmotor.Text = "Ligar Motor"
        Me.BtnLigarmotor.UseVisualStyleBackColor = True
        '
        'ShowBDToolStripMenuItem
        '
        Me.ShowBDToolStripMenuItem.Name = "ShowBDToolStripMenuItem"
        Me.ShowBDToolStripMenuItem.Size = New System.Drawing.Size(224, 26)
        Me.ShowBDToolStripMenuItem.Text = "Show BD"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.BtnLigarmotor)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Btnencerrar)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtPP6 As TextBox
    Friend WithEvents txtPP5 As TextBox
    Friend WithEvents txtPP4 As TextBox
    Friend WithEvents txtPP3 As TextBox
    Friend WithEvents txtPP2 As TextBox
    Friend WithEvents txtPP1 As TextBox
    Friend WithEvents Btnget As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtdestino As ComboBox
    Friend WithEvents Txtpalete As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Btnmove As Button
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents BtnX3 As CheckBox
    Friend WithEvents BtnX2 As CheckBox
    Friend WithEvents BtnX5 As CheckBox
    Friend WithEvents BtnX4 As CheckBox
    Friend WithEvents BtnX0 As CheckBox
    Friend WithEvents BtnX1 As CheckBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Btnoperacao As CheckBox
    Friend WithEvents Btndistribuicao As CheckBox
    Friend WithEvents Btncontagem As CheckBox
    Friend WithEvents Btninicializa As CheckBox
    Friend WithEvents Btnencerrar As Button
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents BaseDeDadosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ConnectToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents BtnLigarmotor As Button
    Friend WithEvents ShowBDToolStripMenuItem As ToolStripMenuItem
End Class
