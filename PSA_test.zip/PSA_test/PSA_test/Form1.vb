﻿Imports ActUtlTypeLib
Imports MySql.Data.MySqlClient
Public Class Form1
    Dim mx As New ActUtlType

    Dim codigo, dados(10), posicao(10) As Long

    Dim cn As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim data_reader As MySqlDataReader

    Private Sub ConnectToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConnectToolStripMenuItem.Click
        ' Ligação e Abertura da Base de Dados e Selecção do Esquema
        cn.ConnectionString = "Server=localhost; User Id=root; Password=0000; Database=psa"
        Try
            If cn.State = ConnectionState.Closed Then
                cn.Open()
                MsgBox("Ligação Correcta à Base de Dados PSA")
            End If
        Catch ex As Exception
            cn.Close()
            MsgBox("Ligação Incorrecta à Base de Dados PSA")
        End Try
        cmd.Connection = cn
        ToolStripStatusLabel1.Text = "Ligado"
        ConnectToolStripMenuItem.Text = "Terminar"

    End Sub




    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        mx.ReadDeviceRandom("M0", 1, dados(6))
        Btninicializa.Checked = If(dados(6) = 1, True, False)
        mx.ReadDeviceRandom("M10", 1, dados(7))
        Btncontagem.Checked = If(dados(7) = 1, True, False)
        mx.ReadDeviceRandom("M10", 1, dados(8))
        mx.ReadDeviceRandom("M30", 1, dados(10))
        Btndistribuicao.Checked = If(dados(8) = 1 Or dados(10) = 1, True, False)
        mx.ReadDeviceRandom("M20", 1, dados(9))
        Btnoperacao.Checked = If(dados(9) = 1, True, False)
        mx.ReadDeviceRandom("X00", 1, dados(0))
        BtnX0.Checked = If(dados(0) = 1, True, False)
        mx.ReadDeviceRandom("X01", 1, dados(1))
        BtnX1.Checked = If(dados(1) = 1, True, False)
        mx.ReadDeviceRandom("X02", 1, dados(2))
        BtnX2.Checked = If(dados(2) = 1, True, False)
        mx.ReadDeviceRandom("X03", 1, dados(3))
        BtnX3.Checked = If(dados(3) = 1, True, False)
        mx.ReadDeviceRandom("X04", 1, dados(4))
        BtnX4.Checked = If(dados(4) = 1, True, False)
        mx.ReadDeviceRandom("X05", 1, dados(5))
        BtnX5.Checked = If(dados(5) = 1, True, False)
    End Sub



    Private Sub Btnget_Click(sender As Object, e As EventArgs) Handles Btnget.Click
        mx.ReadDeviceRandom("D271", 1, posicao(4))
        txtPP1.Text = posicao(4)
        mx.ReadDeviceRandom("D272", 1, posicao(5))
        txtPP2.Text = posicao(5)
        mx.ReadDeviceRandom("D273", 1, posicao(6))
        txtPP3.Text = posicao(6)
        mx.ReadDeviceRandom("D274", 1, posicao(7))
        txtPP4.Text = posicao(7)
        mx.ReadDeviceRandom("D275", 1, posicao(8))
        txtPP5.Text = posicao(8)
        mx.ReadDeviceRandom("D276", 1, posicao(9))
        txtPP6.Text = posicao(9)



    End Sub


    Private Sub Btninicializa_CheckedChanged(sender As Object, e As EventArgs) Handles Btninicializa.CheckedChanged
        If dados(6) = 1 Then
            cmd.CommandText = "Insert into registo_de_dados(Operação,Palete,Destino) Values('" & "Inicialização on" & "','" &
"0" & "','" & "0" & "')"
        Else
            cmd.CommandText = "Insert into registo_de_dados(Operação,Palete,Destino) Values('" & "Inicialização off" & "','" &
"0" & "','" & "0" & "')"

        End If
        If cn.State = ConnectionState.Open Then
            cmd.ExecuteNonQuery()
        End If

    End Sub

    Private Sub Btncontagem_CheckedChanged(sender As Object, e As EventArgs) Handles Btncontagem.CheckedChanged
        If dados(7) = 1 Then
            cmd.CommandText = "Insert into registo_de_dados(Operação,Palete,Destino) Values('" & "Contagem on" & "','" &
"0" & "','" & "0" & "')"
        Else
            cmd.CommandText = "Insert into registo_de_dados(Operação,Palete,Destino) Values('" & "Contagem off" & "','" &
"0" & "','" & "0" & "')"

        End If

        If cn.State = ConnectionState.Open Then
            cmd.ExecuteNonQuery()
        End If

    End Sub

    Private Sub Btndistribuicao_CheckedChanged(sender As Object, e As EventArgs) Handles Btndistribuicao.CheckedChanged
        If dados(8) = 1 Then
            cmd.CommandText = "Insert into registo_de_dados(Operação,Palete,Destino) Values('" & "Distribuição on" & "','" &
"0" & "','" & "0" & "')"
        Else
            cmd.CommandText = "Insert into registo_de_dados(Operação,Palete,Destino) Values('" & "Distribuição off" & "','" &
"0" & "','" & "0" & "')"

        End If

        If cn.State = ConnectionState.Open Then
            cmd.ExecuteNonQuery()
        End If

    End Sub

    Private Sub Btnoperacao_CheckedChanged(sender As Object, e As EventArgs) Handles Btnoperacao.CheckedChanged
        If dados(9) = 1 Then
            cmd.CommandText = "Insert into registo_de_dados(Operação,Palete,Destino) Values('" & "Operação on" & "','" &
"0" & "','" & "0" & "')"
        Else
            cmd.CommandText = "Insert into registo_de_dados(Operação,Palete,Destino) Values('" & "Operação off" & "','" &
"0" & "','" & "0" & "')"

        End If
        If cn.State = ConnectionState.Open Then
            cmd.ExecuteNonQuery()
        End If
    End Sub

    Private Sub Btnmove_Click(sender As Object, e As EventArgs) Handles Btnmove.Click
        posicao(0) = CInt(Txtpalete.Text)
        mx.WriteDeviceRandom("D260", 1, posicao(0))  'envia o nº da palete
        posicao(1) = CInt(txtdestino.Text)
        mx.WriteDeviceRandom("D261", 1, posicao(1)) 'envia o nº da palete

        mx.WriteDeviceRandom("M201", 1, True)

        cmd.CommandText = "Insert into registo_de_dados(Operação,Palete,Destino) Values('" & "Mover Palete" & "','" &
Txtpalete.Text & "','" & txtdestino.Text & "')"

        If cn.State = ConnectionState.Open Then
            cmd.ExecuteNonQuery()
        End If


    End Sub

    Private Sub BtnLigarmotor_Click(sender As Object, e As EventArgs) Handles BtnLigarmotor.Click
        mx.ReadDeviceRandom("M250", 1, posicao(10))
        If Btnoperacao.Checked Then
            mx.WriteDeviceRandom("M250", 1, If(posicao(10) = 1, False, True))
        End If
        If posicao(10) = 0 Then
            BtnLigarmotor.Text = "Desligar Motor"
        Else
            BtnLigarmotor.Text = "Ligar Motor"
        End If
    End Sub

    Private Sub ShowBDToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowBDToolStripMenuItem.Click
        Form2.ShowDialog()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mx.ActLogicalStationNumber = 1


        mx.Open()
    End Sub
    Private Sub Btnencerrar_Click(sender As Object, e As EventArgs) Handles Btnencerrar.Click
        End
    End Sub
End Class
