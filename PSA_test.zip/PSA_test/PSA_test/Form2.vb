﻿Imports MySql.Data.MySqlClient
Public Class Form2
    Dim cn As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim data_reader As MySqlDataReader

    Private Sub BtnlerBD_Click(sender As Object, e As EventArgs) Handles BtnlerBD.Click
        ' Leitura sequencial dos dados existentes na base de dados

        Dim str As String

        'Selecção da tabela da base de dados para leitura dos dados
        cmd.CommandText = "SELECT * FROM registo_de_dados"
        data_reader = cmd.ExecuteReader
        ' Leitura sequencial da tabela.. Guarda o conteúdo dos registos na variável str
        While data_reader.Read
            str = str & data_reader("N") & vbTab & data_reader("Data") & vbTab & data_reader("Operação") & vbTab & data_reader("Palete") & vbTab & data_reader("Destino") & vbCrLf
        End While
        TextBox1.Text = str ' Visualiza os dados de todos os registos
        data_reader.Close()

    End Sub

    Private Sub Btnclose_Click(sender As Object, e As EventArgs) Handles Btnclose.Click
        Close()
    End Sub

    Private Sub Btnapagar_Click(sender As Object, e As EventArgs) Handles Btnapagar.Click
        Dim ltr As String
        MessageBox.Show("Deseja apagar toda a informação da base de dados?", "ATENÇÃO", MessageBoxButtons.YesNo)

        If Windows.Forms.DialogResult.Yes Then
            ' Apagar Registo através da chave de indexação
            cmd.CommandText = "Delete From registo_de_dados"
            cmd.ExecuteNonQuery()
            TextBox1.Text = ""

        End If
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cn.ConnectionString = "Server=localhost; User Id=root; Password=0000; Database=psa"
        If cn.State = ConnectionState.Closed Then
            cn.Open()
        End If
        cmd.Connection = cn
    End Sub
End Class