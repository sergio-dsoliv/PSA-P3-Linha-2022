﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.BtnlerBD = New System.Windows.Forms.Button()
        Me.Btnclose = New System.Windows.Forms.Button()
        Me.Btnapagar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(182, 51)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(527, 329)
        Me.TextBox1.TabIndex = 0
        '
        'BtnlerBD
        '
        Me.BtnlerBD.Location = New System.Drawing.Point(12, 51)
        Me.BtnlerBD.Name = "BtnlerBD"
        Me.BtnlerBD.Size = New System.Drawing.Size(128, 50)
        Me.BtnlerBD.TabIndex = 1
        Me.BtnlerBD.Text = "Ler Base de Dados"
        Me.BtnlerBD.UseVisualStyleBackColor = True
        '
        'Btnclose
        '
        Me.Btnclose.Location = New System.Drawing.Point(667, 415)
        Me.Btnclose.Name = "Btnclose"
        Me.Btnclose.Size = New System.Drawing.Size(75, 23)
        Me.Btnclose.TabIndex = 2
        Me.Btnclose.Text = "Fechar"
        Me.Btnclose.UseVisualStyleBackColor = True
        '
        'Btnapagar
        '
        Me.Btnapagar.Location = New System.Drawing.Point(12, 158)
        Me.Btnapagar.Name = "Btnapagar"
        Me.Btnapagar.Size = New System.Drawing.Size(128, 46)
        Me.Btnapagar.TabIndex = 3
        Me.Btnapagar.Text = "Apagar BD"
        Me.Btnapagar.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Btnapagar)
        Me.Controls.Add(Me.Btnclose)
        Me.Controls.Add(Me.BtnlerBD)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents BtnlerBD As Button
    Friend WithEvents Btnclose As Button
    Friend WithEvents Btnapagar As Button
End Class
